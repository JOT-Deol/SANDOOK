SANDOOK ICON UPDATE

Upload the icons folder and manifest.webmanifest to the root of your GitHub Pages repository.
For index.html: do NOT replace your working page with the minimal sample index.html included here.
Instead, add this line inside the existing <head> section:
<link rel="apple-touch-icon" href="./icons/icon-512.png">
Also add:
<link rel="manifest" href="./manifest.webmanifest">

After GitHub Pages updates, delete the old Home Screen shortcut and add SANDOOK again from Safari.
